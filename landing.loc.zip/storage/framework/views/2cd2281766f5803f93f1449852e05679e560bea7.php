<?php $__env->startSection('content'); ?>

<table class="table table-bordered">
    <thead>
    <tr>
        <th scope="col">ID</th>
        <th scope="col">URL</th>
        <th scope="col">Views</th>
        <th scope="col">Last Visit</th>
    </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $visits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $visit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <th scope="row"><?php echo e($visit['id']); ?></th>
            <td><?php echo e($visit['url']); ?></td>
            <td><?php echo e($visit['views']); ?></td>
            <td><?php echo e($visit['last_visit']); ?></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

<?php echo e($visits->links()); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\OpenServer\domains\volta-work\landing.loc\resources\views/admin/activity.blade.php ENDPATH**/ ?>